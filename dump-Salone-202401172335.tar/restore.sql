--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Salone";
--
-- Name: Salone; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Salone" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE "Salone" OWNER TO postgres;

\connect "Salone"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: after_insert_booking(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.after_insert_booking() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare duration INTEGER;
declare da date;
declare o TIME;
begin 
	select s.duration into duration from services as s inner join bookingsdate as bd on (s.id_service = bd.id_service)
	inner join bookings as b on (bd.id_bookingdate = b.id_bookingdate)
	where b.id_booking = new.id_booking;
	
	select bd."data" , bd.ora into da, o
	from bookingsdate as bd
	inner join bookings as b ON (bd.id_bookingdate = b.id_bookingdate)
	where b.id_booking = new.id_booking;

	 DELETE FROM bookingsdate as bd
     WHERE bd."data" = da
      AND bd.ora >= o
      AND bd.ora < o + interval '1 hour' * duration
      and bd.isvalid = true;
     
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.after_insert_booking() OWNER TO postgres;

--
-- Name: isvalidcheck(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.isvalidcheck() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    riga RECORD;
BEGIN
    FOR riga IN SELECT * FROM bookingsdate LOOP
        IF riga.isvalid = false and riga.data < current_date THEN
            DELETE FROM bookingsdate WHERE id_bookingdate = riga.id_bookingdate;
        END IF;
    END LOOP;
END;
$$;


ALTER FUNCTION public.isvalidcheck() OWNER TO postgres;

--
-- Name: removeinvalidbookingdate(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.removeinvalidbookingdate() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    riga RECORD;
BEGIN
 
END;
$$;


ALTER FUNCTION public.removeinvalidbookingdate() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id_booking bigint NOT NULL,
    id_user bigint NOT NULL,
    id_bookingdate bigint NOT NULL,
    payment_intent character varying
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_booking_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bookings ALTER COLUMN id_booking ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bookings_id_booking_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bookingsdate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookingsdate (
    id_bookingdate bigint NOT NULL,
    id_service bigint NOT NULL,
    data date NOT NULL,
    ora time without time zone NOT NULL,
    isvalid boolean NOT NULL
);


ALTER TABLE public.bookingsdate OWNER TO postgres;

--
-- Name: bookingsdate_id_bookingdate_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bookingsdate ALTER COLUMN id_bookingdate ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bookingsdate_id_bookingdate_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: carts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carts (
    id_cart bigint NOT NULL,
    id_user bigint NOT NULL
);


ALTER TABLE public.carts OWNER TO postgres;

--
-- Name: cart_id_cart_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.carts ALTER COLUMN id_cart ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.cart_id_cart_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: duration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.duration (
    duration bigint
);


ALTER TABLE public.duration OWNER TO postgres;

--
-- Name: hairdressers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hairdressers (
    id_hairdresser bigint NOT NULL,
    email character varying(50) NOT NULL,
    password character varying(500) NOT NULL
);


ALTER TABLE public.hairdressers OWNER TO postgres;

--
-- Name: hairdressers_id_hairdresser_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.hairdressers ALTER COLUMN id_hairdresser ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.hairdressers_id_hairdresser_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id_product bigint NOT NULL,
    name character varying(25) NOT NULL,
    description character varying(500) NOT NULL,
    category character varying(25) NOT NULL,
    price double precision NOT NULL,
    image character varying,
    id_hairdresser integer
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: prodotti_id_prodotto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.products ALTER COLUMN id_product ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.prodotti_id_prodotto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: products_cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products_cart (
    id_product_cart bigint NOT NULL,
    id_cart bigint NOT NULL,
    id_product bigint NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.products_cart OWNER TO postgres;

--
-- Name: products_cart_id_product_cart_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.products_cart ALTER COLUMN id_product_cart ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.products_cart_id_product_cart_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id_service bigint NOT NULL,
    name character varying(25) NOT NULL,
    description character varying(500) NOT NULL,
    category character varying(25) NOT NULL,
    price double precision NOT NULL,
    sex character varying NOT NULL,
    duration bigint
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: servizio_id_servizio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.services ALTER COLUMN id_service ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.servizio_id_servizio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id_user bigint NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(500) NOT NULL,
    name character varying(50) NOT NULL,
    surname character varying(50) NOT NULL,
    tel_number character varying(50) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id_user ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_user_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (id_booking, id_user, id_bookingdate, payment_intent) FROM stdin;
\.
COPY public.bookings (id_booking, id_user, id_bookingdate, payment_intent) FROM '$$PATH$$/4905.dat';

--
-- Data for Name: bookingsdate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookingsdate (id_bookingdate, id_service, data, ora, isvalid) FROM stdin;
\.
COPY public.bookingsdate (id_bookingdate, id_service, data, ora, isvalid) FROM '$$PATH$$/4907.dat';

--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carts (id_cart, id_user) FROM stdin;
\.
COPY public.carts (id_cart, id_user) FROM '$$PATH$$/4919.dat';

--
-- Data for Name: duration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.duration (duration) FROM stdin;
\.
COPY public.duration (duration) FROM '$$PATH$$/4917.dat';

--
-- Data for Name: hairdressers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hairdressers (id_hairdresser, email, password) FROM stdin;
\.
COPY public.hairdressers (id_hairdresser, email, password) FROM '$$PATH$$/4909.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id_product, name, description, category, price, image, id_hairdresser) FROM stdin;
\.
COPY public.products (id_product, name, description, category, price, image, id_hairdresser) FROM '$$PATH$$/4911.dat';

--
-- Data for Name: products_cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products_cart (id_product_cart, id_cart, id_product, quantity) FROM stdin;
\.
COPY public.products_cart (id_product_cart, id_cart, id_product, quantity) FROM '$$PATH$$/4921.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id_service, name, description, category, price, sex, duration) FROM stdin;
\.
COPY public.services (id_service, name, description, category, price, sex, duration) FROM '$$PATH$$/4913.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id_user, email, password, name, surname, tel_number) FROM stdin;
\.
COPY public.users (id_user, email, password, name, surname, tel_number) FROM '$$PATH$$/4915.dat';

--
-- Name: bookings_id_booking_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_id_booking_seq', 26, true);


--
-- Name: bookingsdate_id_bookingdate_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookingsdate_id_bookingdate_seq', 297, true);


--
-- Name: cart_id_cart_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cart_id_cart_seq', 14, true);


--
-- Name: hairdressers_id_hairdresser_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hairdressers_id_hairdresser_seq', 2, true);


--
-- Name: prodotti_id_prodotto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prodotti_id_prodotto_seq', 3, true);


--
-- Name: products_cart_id_product_cart_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_cart_id_product_cart_seq', 17, true);


--
-- Name: servizio_id_servizio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.servizio_id_servizio_seq', 46, true);


--
-- Name: users_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_user_seq', 5, true);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id_booking);


--
-- Name: bookingsdate bookingsdate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookingsdate
    ADD CONSTRAINT bookingsdate_pkey PRIMARY KEY (id_bookingdate);


--
-- Name: carts cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id_cart);


--
-- Name: carts carts_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_un UNIQUE (id_user);


--
-- Name: hairdressers hairdressers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hairdressers
    ADD CONSTRAINT hairdressers_pkey PRIMARY KEY (id_hairdresser);


--
-- Name: hairdressers hairdressers_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hairdressers
    ADD CONSTRAINT hairdressers_username_key UNIQUE (email);


--
-- Name: products prodotti_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT prodotti_pkey PRIMARY KEY (id_product);


--
-- Name: products_cart products_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_cart
    ADD CONSTRAINT products_cart_pkey PRIMARY KEY (id_product_cart);


--
-- Name: products products_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_un UNIQUE (name);


--
-- Name: services servizio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT servizio_pkey PRIMARY KEY (id_service);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_user);


--
-- Name: bookings after_insert_booking_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER after_insert_booking_trigger AFTER INSERT ON public.bookings FOR EACH ROW EXECUTE FUNCTION public.after_insert_booking();


--
-- Name: bookings bookings_id_bookingdate_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_id_bookingdate_fkey FOREIGN KEY (id_bookingdate) REFERENCES public.bookingsdate(id_bookingdate);


--
-- Name: bookings bookings_id_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_id_user_fkey FOREIGN KEY (id_user) REFERENCES public.users(id_user);


--
-- Name: bookingsdate bookingsdate_id_service_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookingsdate
    ADD CONSTRAINT bookingsdate_id_service_fkey FOREIGN KEY (id_service) REFERENCES public.services(id_service);


--
-- Name: carts cart_id_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT cart_id_user_fkey FOREIGN KEY (id_user) REFERENCES public.users(id_user);


--
-- Name: products id_hairdresser; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT id_hairdresser FOREIGN KEY (id_hairdresser) REFERENCES public.hairdressers(id_hairdresser);


--
-- Name: products_cart products_cart_id_cart_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_cart
    ADD CONSTRAINT products_cart_id_cart_fkey FOREIGN KEY (id_cart) REFERENCES public.carts(id_cart);


--
-- Name: products_cart products_cart_id_product_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_cart
    ADD CONSTRAINT products_cart_id_product_fkey FOREIGN KEY (id_product) REFERENCES public.products(id_product);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

