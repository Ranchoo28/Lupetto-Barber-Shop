--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Salone";
--
-- Name: Salone; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Salone" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE "Salone" OWNER TO postgres;

\connect "Salone"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: isvalidcheck(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.isvalidcheck() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    riga RECORD;
BEGIN
    FOR riga IN SELECT * FROM bookingsdate LOOP
        IF riga.isvalid = false and riga.data < current_date THEN
            DELETE FROM bookingsdate WHERE id_bookingdate = riga.id_bookingdate;
        END IF;
    END LOOP;
END;
$$;


ALTER FUNCTION public.isvalidcheck() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id_booking bigint NOT NULL,
    id_user bigint NOT NULL,
    id_bookingdate bigint NOT NULL
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_booking_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bookings ALTER COLUMN id_booking ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bookings_id_booking_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bookingsdate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookingsdate (
    id_bookingdate bigint NOT NULL,
    id_service bigint NOT NULL,
    data date NOT NULL,
    ora time without time zone NOT NULL,
    isvalid boolean NOT NULL
);


ALTER TABLE public.bookingsdate OWNER TO postgres;

--
-- Name: bookingsdate_id_bookingdate_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bookingsdate ALTER COLUMN id_bookingdate ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bookingsdate_id_bookingdate_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hairdressers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hairdressers (
    id_hairdresser bigint NOT NULL,
    email character varying(50) NOT NULL,
    password character varying(500) NOT NULL
);


ALTER TABLE public.hairdressers OWNER TO postgres;

--
-- Name: hairdressers_id_hairdresser_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.hairdressers ALTER COLUMN id_hairdresser ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.hairdressers_id_hairdresser_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id_product bigint NOT NULL,
    name character varying(25) NOT NULL,
    description character varying(500) NOT NULL,
    category character varying(25) NOT NULL,
    price double precision
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: prodotti_id_prodotto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.products ALTER COLUMN id_product ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.prodotti_id_prodotto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id_service bigint NOT NULL,
    name character varying(25) NOT NULL,
    description character varying(500) NOT NULL,
    category character varying(25) NOT NULL,
    price double precision NOT NULL,
    sex character varying NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: servizio_id_servizio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.services ALTER COLUMN id_service ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.servizio_id_servizio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id_user bigint NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(500) NOT NULL,
    name character varying(50) NOT NULL,
    surname character varying(50) NOT NULL,
    tel_number character varying(50) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id_user ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_user_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (id_booking, id_user, id_bookingdate) FROM stdin;
\.
COPY public.bookings (id_booking, id_user, id_bookingdate) FROM '$$PATH$$/4889.dat';

--
-- Data for Name: bookingsdate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookingsdate (id_bookingdate, id_service, data, ora, isvalid) FROM stdin;
\.
COPY public.bookingsdate (id_bookingdate, id_service, data, ora, isvalid) FROM '$$PATH$$/4887.dat';

--
-- Data for Name: hairdressers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hairdressers (id_hairdresser, email, password) FROM stdin;
\.
COPY public.hairdressers (id_hairdresser, email, password) FROM '$$PATH$$/4885.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id_product, name, description, category, price) FROM stdin;
\.
COPY public.products (id_product, name, description, category, price) FROM '$$PATH$$/4883.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id_service, name, description, category, price, sex) FROM stdin;
\.
COPY public.services (id_service, name, description, category, price, sex) FROM '$$PATH$$/4881.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id_user, email, password, name, surname, tel_number) FROM stdin;
\.
COPY public.users (id_user, email, password, name, surname, tel_number) FROM '$$PATH$$/4891.dat';

--
-- Name: bookings_id_booking_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_id_booking_seq', 1, false);


--
-- Name: bookingsdate_id_bookingdate_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookingsdate_id_bookingdate_seq', 13, true);


--
-- Name: hairdressers_id_hairdresser_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hairdressers_id_hairdresser_seq', 2, true);


--
-- Name: prodotti_id_prodotto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prodotti_id_prodotto_seq', 2, true);


--
-- Name: servizio_id_servizio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.servizio_id_servizio_seq', 2, true);


--
-- Name: users_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_user_seq', 5, true);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id_booking);


--
-- Name: bookingsdate bookingsdate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookingsdate
    ADD CONSTRAINT bookingsdate_pkey PRIMARY KEY (id_bookingdate);


--
-- Name: hairdressers hairdressers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hairdressers
    ADD CONSTRAINT hairdressers_pkey PRIMARY KEY (id_hairdresser);


--
-- Name: hairdressers hairdressers_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hairdressers
    ADD CONSTRAINT hairdressers_username_key UNIQUE (email);


--
-- Name: products prodotti_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT prodotti_pkey PRIMARY KEY (id_product);


--
-- Name: products products_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_un UNIQUE (name);


--
-- Name: services services_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_un UNIQUE (name);


--
-- Name: services servizio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT servizio_pkey PRIMARY KEY (id_service);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_user);


--
-- Name: bookings bookings_id_bookingdate_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_id_bookingdate_fkey FOREIGN KEY (id_bookingdate) REFERENCES public.bookingsdate(id_bookingdate);


--
-- Name: bookings bookings_id_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_id_user_fkey FOREIGN KEY (id_user) REFERENCES public.users(id_user);


--
-- Name: bookingsdate bookingsdate_id_service_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookingsdate
    ADD CONSTRAINT bookingsdate_id_service_fkey FOREIGN KEY (id_service) REFERENCES public.services(id_service);


--
-- PostgreSQL database dump complete
--

